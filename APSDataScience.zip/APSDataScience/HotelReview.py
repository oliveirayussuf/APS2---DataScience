import pandas as pd
import re
import nltk
from nltk.corpus import stopwords
from nltk.tokenize import word_tokenize
from nltk.stem import WordNetLemmatizer
from nltk.sentiment import SentimentIntensityAnalyzer
from collections import Counter
import matplotlib.pyplot as plt
from wordcloud import WordCloud


# Baixar recursos necessários do NLTK
nltk.download([
    'punkt',
    'stopwords',
    'wordnet',
    'vader_lexicon'
])

# Carregar o dataset
df = pd.read_csv('Hotel_Reviews.csv')

# Pré-processamento de texto
stop_words = set(stopwords.words('english'))
lemmatizer = WordNetLemmatizer()

def clean_text(text):
    # Remover caracteres especiais e números
    text = re.sub(r'[^a-zA-Z\s]', '', text, re.I|re.A)
    # Converter para minúsculas
    text = text.lower()
    # Tokenização
    tokens = word_tokenize(text)
    # Remover stopwords e lematização
    tokens = [lemmatizer.lemmatize(word) for word in tokens if word not in stop_words]
    return ' '.join(tokens)

# Aplicar limpeza nas colunas de reviews
df['Cleaned_Negative'] = df['Negative_Review'].apply(clean_text)
df['Cleaned_Positive'] = df['Positive_Review'].apply(clean_text)

# Combinar todos os textos para análise
all_reviews = ' '.join(df['Cleaned_Negative'] + ' ' + df['Cleaned_Positive'])

# Análise de Sentimento com VADER
sia = SentimentIntensityAnalyzer()

def get_sentiment(text):
    scores = sia.polarity_scores(text)
    if scores['compound'] >= 0.05:
        return 'Positive'
    elif scores['compound'] <= -0.05:
        return 'Negative'
    else:
        return 'Neutral'

# Aplicar análise de sentimento
df['Sentiment'] = df.apply(
    lambda row: get_sentiment(row['Cleaned_Negative'] + ' ' + row['Cleaned_Positive']),
    axis=1
)

# Análise de palavras mais frequentes
all_words = word_tokenize(all_reviews)
word_freq = Counter(all_words).most_common(20)

# Gerar nuvem de palavras
wordcloud = WordCloud(width=800, height=400, background_color='white').generate(all_reviews)

# Visualizações
plt.figure(figsize=(15, 10))

# Gráfico 1: Distribuição de Sentimentos
plt.subplot(2, 2, 1)
sentiment_counts = df['Sentiment'].value_counts()
sentiment_counts.plot(kind='bar', color=['green', 'red', 'blue'])
plt.title('Distribuição de Sentimentos')
plt.ylabel('Quantidade')

# Gráfico 2: Palavras mais frequentes
plt.subplot(2, 2, 2)
words, counts = zip(*word_freq)
plt.barh(words, counts, color='skyblue')
plt.title('Top 20 Palavras mais Frequentes')
plt.gca().invert_yaxis()

# Gráfico 3: Nuvem de palavras
plt.subplot(2, 1, 2)
plt.imshow(wordcloud, interpolation='bilinear')
plt.axis('off')
plt.title('Nuvem de Palavras das Avaliações')

plt.tight_layout()
plt.show()

# Insights estatísticos
print("\n" + "="*50)
print("Principais Insights:")
print("="*50)
print(f"1. Proporção de Sentimentos:\n{sentiment_counts / len(df)}")
print(f"\n2. Palavras mais comuns em avaliações negativas: {Counter(word_tokenize(' '.join(df['Cleaned_Negative']))}")
print(f"\n3. Palavras mais comuns em avaliações positivas: {Counter(word_tokenize(' '.join(df['Cleaned_Positive']))}")
print(f"\n4. Média de palavras por avaliação: {len(all_words)/len(df):.1f}")

# Análise por nacionalidade
if 'Reviewer_Nationality' in df.columns:
    nationality_sentiment = df.groupby('Reviewer_Nationality')['Sentiment'].value_counts(normalize=True)
    print("\n5. Distribuição de sentimentos por nacionalidade:")
    print(nationality_sentiment.head(10))